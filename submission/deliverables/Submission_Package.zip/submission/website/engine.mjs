// Parameter-level inference shared by the hosted site and the Node parity check.
export const sigmoid = x => x>=0 ? 1/(1+Math.exp(-x)) : Math.exp(x)/(1+Math.exp(x));
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const linear=(x,w,b)=>w.map((row,i)=>dot(row,x)+b[i]);
const relu=x=>x.map(v=>Math.max(0,v));
function conv(x,w,b){return w.map((channels,o)=>x[0].map((_,i)=>b[o]+channels.reduce((s,kernel,c)=>s+kernel.reduce((z,v,k)=>z+v*(x[c][i+k-1]??0),0),0)));}
export function predict(model,x){
  if(model.type==='linear')return sigmoid(dot(model.weights,x)+model.bias);
  if(model.type==='forest'){
    // sklearn trees cast prediction input to float32.
    const v=x.map(Math.fround);
    return model.trees.reduce((s,t)=>{let i=0;while(t.left[i]!==-1)i=v[t.feature[i]]<=t.threshold[i]?t.left[i]:t.right[i];return s+t.value[i];},0)/model.trees.length;
  }
  if(model.type==='svm')return sigmoid(model.bias+model.support.reduce((s,v,i)=>s+model.dual[i]*Math.exp(-model.gamma*v.reduce((z,a,j)=>z+(a-x[j])**2,0)),0));
  if(model.type==='hist')return sigmoid(model.base+model.trees.reduce((s,t)=>{let i=0;while(!t[i].is_leaf)i=x[t[i].feature_idx]<=t[i].num_threshold?t[i].left:t[i].right;return s+t[i].value;},0));
  if(model.type==='xgboost')return sigmoid(model.base+model.trees.reduce((s,root)=>{let t=root;while(t.leaf===undefined){const child=Math.fround(x[Number(t.split.slice(1))])<Math.fround(t.split_condition)?t.yes:t.no;t=t.children.find(v=>v.nodeid===child);}return s+t.leaf;},0));
  const s=model.state;
  const dense=(v,p)=>linear(v,s[p+'.weight'],s[p+'.bias']);
  if(model.type==='MLP')return sigmoid(dense(relu(dense(relu(dense(x,'network.0')),'network.3')),'network.6')[0]);
  if(model.type==='ResidualMLP'){
    let v=relu(dense(x,'input'));
    for(let i=0;i<2;i++){const u=dense(relu(dense(v,`blocks.${i}.layers.0`)),`blocks.${i}.layers.3`);v=relu(v.map((a,j)=>a+u[j]));}
    return sigmoid(dense(v,'output')[0]);
  }
  if(model.type==='CNN1D'){
    const a=conv([x],s['conv.0.weight'],s['conv.0.bias']).map(relu);
    const b=conv(a,s['conv.2.weight'],s['conv.2.bias']).map(relu).flat();
    return sigmoid(dense(relu(dense(b,'head.2')),'head.4')[0]);
  }
  throw new Error('Unsupported model');
}
export function transform(claim,c){
  const d=new Date(claim.ClaimDate+'T00:00:00Z');
  if(!Number.isFinite(d.getTime())||d.toISOString().slice(0,10)!==claim.ClaimDate)throw new Error('Enter a valid claim date.');
  const row={...claim,ClaimYear:d.getUTCFullYear(),ClaimMonth:d.getUTCMonth()+1,ClaimDayOfWeek:(d.getUTCDay()+6)%7};
  const x=c.numeric.map((k,i)=>{
    const v=Number(row[k]);if(row[k]===''||row[k]===undefined||!Number.isFinite(v))throw new Error('Enter a valid '+k+'.');
    if(v<0 || (k==='PatientAge'&&(!Number.isInteger(v)||v>120)) || (k==='Cluster'&&(!Number.isInteger(v)||v>3)))throw new Error('Value outside permitted range for '+k+'.');
    return (v-c.mean[i])/c.scale[i];
  });
  c.categorical.forEach((k,i)=>{if(!c.categories[i].includes(row[k]))throw new Error('Unknown '+k+'.');c.categories[i].forEach(v=>x.push(row[k]===v?1:0));});
  return x.map(Math.fround);
}
